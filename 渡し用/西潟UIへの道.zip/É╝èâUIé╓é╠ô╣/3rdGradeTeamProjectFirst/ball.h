//====================================================================
//
// �{�[���̏��� (ball.h)
// Author : �㓡�T�V��
//
//====================================================================
#ifndef _MODELEFFECT_H_
#define _MODELEFFECT_H_

//================================================
// �C���N���[�h�t�@�C��
//================================================
#include "main.h"
#include "scene3d.h"

//================================================
// �}�N����`
//================================================

#define BALL_COLLISION_SIZE D3DXVECTOR3(50.0f, 50.0f, 50.0f)

//================================================
// �N���X�錾
//================================================

// �{�[���N���X
class CBall : public CScene3D
{
public:

    CBall();
    ~CBall();
    HRESULT Init(D3DXVECTOR3 pos, D3DXVECTOR3 size);
    void Uninit(void);
    void Update(void);
    void Draw(void);
    static CBall *Create(D3DXVECTOR3 pos);

    void Shoot(D3DXVECTOR3 moveAngle, float fPower);

private:
    D3DXVECTOR3 m_moveAngle;                     // �ړ�����p�x
    float m_fSpeed;                              // ����
};

#endif