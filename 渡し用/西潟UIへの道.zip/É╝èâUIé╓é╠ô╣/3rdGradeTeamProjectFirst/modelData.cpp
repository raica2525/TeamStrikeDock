//=============================================================================
//
// ���f���f�[�^�̏��� [modelData.cpp]
// Author : �㓡�T�V��
//
//=============================================================================

#define _CRT_SECURE_NO_WARNINGS

//=============================================================================
// �C���N���[�h
//=============================================================================
#include "modelData.h"
#include "manager.h"
#include "renderer.h"

//=============================================================================
// �}�N����`
//=============================================================================
#define MODEL_DATA_FILENAME ("data/TXT/modelData.txt")	    // ���f���f�[�^��ǂݍ��ރt�@�C���̖��O
#define PARTS_LIST_FILENAME ("data/TXT/partsList.txt")	    // �p�[�c���X�g��ǂݍ��ރt�@�C���̖��O
#define PARTS_RATE_FILENAME ("data/TXT/partsRate.txt")	    // �p�[�c���[�g��ǂݍ��ރt�@�C���̖��O

//=============================================================================
// �R���X�g���N�^
// Author : �㓡�T�V��
//=============================================================================
CModelData::CModelData()
{
    memset(m_aModelData, 0, sizeof(m_aModelData));
    memset(m_aPartsList, 0, sizeof(m_aPartsList));
    memset(m_aPartsRate, 0, sizeof(m_aPartsRate));
}

//=============================================================================
// �f�X�g���N�^
// Author : �㓡�T�V��
//=============================================================================
CModelData::~CModelData()
{
}

//=============================================================================
// ����������
// Author : �㓡�T�V��
//=============================================================================
HRESULT CModelData::Init(void)
{
    // �t�@�C���|�C���g
    FILE *pFile = NULL;

    // �ϐ��錾
    char cReadText[256];	               // �����Ƃ��ēǂݎ��p
    char cHeadText[256];	               // �����̔��ʗp
    char cDie[256];		                   // �g��Ȃ�����
    int nNumType = 0;                      // �^�C�v�̃i���o�[
    int nNumTexture = NON_TEXTURE;         // �ǂݍ��ރe�N�X�`���ԍ�
    char cLoadModelName[256];              // �ǂݍ��ݎ��̃��f����

    // ���f����ǂݍ��ނ��߂̃f�o�C�X�擾
    LPDIRECT3DDEVICE9 pDevice = CManager::GetRenderer()->GetDevice();

    //======================================================================================
    // ���f���f�[�^�t�@�C�����J��
    pFile = fopen(MODEL_DATA_FILENAME, "r");

    // �J������
    if (pFile != NULL)
    {
        // SCRIPT�̕�����������܂�
        while (strcmp(cHeadText, "SCRIPT") != 0)
        {
            // �e�L�X�g����cReadText���������󂯎��
            fgets(cReadText, sizeof(cReadText), pFile);

            // cReedText��cHeadText�Ɋi�[
            sscanf(cReadText, "%s", &cHeadText);
        }

        // cHeadText��SCRIPT�̎�
        if (strcmp(cHeadText, "SCRIPT") == 0)
        {
            // cHeadText��END_SCRIPT�ɂȂ�܂�
            while (strcmp(cHeadText, "END_SCRIPT") != 0)
            {
                fgets(cReadText, sizeof(cReadText), pFile);
                sscanf(cReadText, "%s", &cHeadText);

                // cHeadText��MODEL_DATASET�̎�
                if (strcmp(cHeadText, "MODEL_DATASET") == 0)
                {
                    // cHeadText��END_MODEL_DATASET�ɂȂ�܂�
                    while (strcmp(cHeadText, "END_MODEL_DATASET") != 0)
                    {
                        fgets(cReadText, sizeof(cReadText), pFile);
                        sscanf(cReadText, "%s", &cHeadText);

                        if (strcmp(cHeadText, "TYPE") == 0)
                        {
                            sscanf(cReadText, "%s %s %d", &cDie, &cDie, &nNumType);

                            // �e�N�X�`���ԍ��̏�����
                            m_aModelData[nNumType].nNumTexture = NON_TEXTURE;
                        }
                        else if (strcmp(cHeadText, "TEX_NUM") == 0)
                        {
                            sscanf(cReadText, "%s %s %d", &cDie, &cDie, &nNumTexture);

                            // �e�N�X�`���f�[�^�̕R�Â�
                            m_aModelData[nNumType].nNumTexture = nNumTexture;
                        }
                        else if (strcmp(cHeadText, "NAME") == 0)
                        {
                            sscanf(cReadText, "%s %s %s", &cDie, &cDie, &cLoadModelName);

                            // ���f���f�[�^�̓ǂݍ���
                            D3DXLoadMeshFromX(LPCSTR(cLoadModelName), D3DXMESH_SYSTEMMEM, pDevice, NULL, 
                                &m_aModelData[nNumType].pBuffMat, NULL, &m_aModelData[nNumType].nNumMat, &m_aModelData[nNumType].pMesh);
                        }
                    }
                }
            }
        }
        // �t�@�C�������
        fclose(pFile);
    }
    // �J���Ȃ�������
    else
    {
        printf("�J����܂���ł���\n");

        return E_FAIL;
    }
    //======================================================================================

    //======================================================================================
    // �p�[�c���X�g�t�@�C�����J��
    pFile = fopen(PARTS_LIST_FILENAME, "r");

    // �J������
    if (pFile != NULL)
    {
        // SCRIPT�̕�����������܂�
        while (strcmp(cHeadText, "SCRIPT") != 0)
        {
            // �e�L�X�g����cReadText���������󂯎��
            fgets(cReadText, sizeof(cReadText), pFile);

            // cReedText��cHeadText�Ɋi�[
            sscanf(cReadText, "%s", &cHeadText);
        }

        // cHeadText��SCRIPT�̎�
        if (strcmp(cHeadText, "SCRIPT") == 0)
        {
            // cHeadText��END_SCRIPT�ɂȂ�܂�
            while (strcmp(cHeadText, "END_SCRIPT") != 0)
            {
                fgets(cReadText, sizeof(cReadText), pFile);
                sscanf(cReadText, "%s", &cHeadText);

                // cHeadText��PARTS_PARAM�̎�
                if (strcmp(cHeadText, "PARTS_PARAM") == 0)
                {
                    // cHeadText��END_PARTS_PARAM�ɂȂ�܂�
                    while (strcmp(cHeadText, "END_PARTS_PARAM") != 0)
                    {
                        fgets(cReadText, sizeof(cReadText), pFile);
                        sscanf(cReadText, "%s", &cHeadText);

                        if (strcmp(cHeadText, "TYPE") == 0)
                        {
                            sscanf(cReadText, "%s %s %d", &cDie, &cDie, &nNumType);
                        }
                        else if (strcmp(cHeadText, "ATK") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fAtk);
                        }
                        else if (strcmp(cHeadText, "DEF") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fDef);
                        }
                        else if (strcmp(cHeadText, "SPD") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fSpd);
                        }
                        else if (strcmp(cHeadText, "WEI") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fWei);
                        }
                        else if (strcmp(cHeadText, "EX") == 0)
                        {
                            sscanf(cReadText, "%s %s %d", &cDie, &cDie, &m_aPartsList[nNumType].nEx);
                        }
                        else if (strcmp(cHeadText, "PARAM0") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[0]);
                        }
                        else if (strcmp(cHeadText, "PARAM1") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[1]);
                        }
                        else if (strcmp(cHeadText, "PARAM2") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[2]);
                        }
                        else if (strcmp(cHeadText, "PARAM3") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[3]);
                        }
                        else if (strcmp(cHeadText, "PARAM4") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[4]);
                        }
                        else if (strcmp(cHeadText, "PARAM5") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[5]);
                        }
                        else if (strcmp(cHeadText, "PARAM6") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[6]);
                        }
                        else if (strcmp(cHeadText, "PARAM7") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsList[nNumType].fParam[7]);
                        }
                    }
                }
            }
        }
        // �t�@�C�������
        fclose(pFile);
    }
    // �J���Ȃ�������
    else
    {
        printf("�J����܂���ł���\n");

        return E_FAIL;
    }
    //======================================================================================

    //======================================================================================
    // �p�[�c���[�g�t�@�C�����J��
    pFile = fopen(PARTS_RATE_FILENAME, "r");

    // �J������
    if (pFile != NULL)
    {
        // SCRIPT�̕�����������܂�
        while (strcmp(cHeadText, "SCRIPT") != 0)
        {
            // �e�L�X�g����cReadText���������󂯎��
            fgets(cReadText, sizeof(cReadText), pFile);

            // cReedText��cHeadText�Ɋi�[
            sscanf(cReadText, "%s", &cHeadText);
        }

        // cHeadText��SCRIPT�̎�
        if (strcmp(cHeadText, "SCRIPT") == 0)
        {
            // cHeadText��END_SCRIPT�ɂȂ�܂�
            while (strcmp(cHeadText, "END_SCRIPT") != 0)
            {
                fgets(cReadText, sizeof(cReadText), pFile);
                sscanf(cReadText, "%s", &cHeadText);

                if (strcmp(cHeadText, "PARTS_RATE_HEAD") == 0)
                {
                    while (strcmp(cHeadText, "END_PARTS_RATE_HEAD") != 0)
                    {
                        fgets(cReadText, sizeof(cReadText), pFile);
                        sscanf(cReadText, "%s", &cHeadText);

                        if (strcmp(cHeadText, "ATK") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[0].fAtkRate);
                        }
                        else if (strcmp(cHeadText, "DEF") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[0].fDefRate);
                        }
                        else if (strcmp(cHeadText, "SPD") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[0].fSpdRate);
                        }
                        else if (strcmp(cHeadText, "WEI") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[0].fWeiRate);
                        }
                    }
                }
                else if (strcmp(cHeadText, "PARTS_RATE_UP") == 0)
                {
                    while (strcmp(cHeadText, "END_PARTS_RATE_UP") != 0)
                    {
                        fgets(cReadText, sizeof(cReadText), pFile);
                        sscanf(cReadText, "%s", &cHeadText);

                        if (strcmp(cHeadText, "ATK") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[1].fAtkRate);
                        }
                        else if (strcmp(cHeadText, "DEF") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[1].fDefRate);
                        }
                        else if (strcmp(cHeadText, "SPD") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[1].fSpdRate);
                        }
                        else if (strcmp(cHeadText, "WEI") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[1].fWeiRate);
                        }
                    }
                }
                else if (strcmp(cHeadText, "PARTS_RATE_DOWN") == 0)
                {
                    while (strcmp(cHeadText, "END_PARTS_RATE_DOWN") != 0)
                    {
                        fgets(cReadText, sizeof(cReadText), pFile);
                        sscanf(cReadText, "%s", &cHeadText);

                        if (strcmp(cHeadText, "ATK") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[2].fAtkRate);
                        }
                        else if (strcmp(cHeadText, "DEF") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[2].fDefRate);
                        }
                        else if (strcmp(cHeadText, "SPD") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[2].fSpdRate);
                        }
                        else if (strcmp(cHeadText, "WEI") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[2].fWeiRate);
                        }
                    }
                }
                else if (strcmp(cHeadText, "PARTS_RATE_WEA") == 0)
                {
                    while (strcmp(cHeadText, "END_PARTS_RATE_WEA") != 0)
                    {
                        fgets(cReadText, sizeof(cReadText), pFile);
                        sscanf(cReadText, "%s", &cHeadText);

                        if (strcmp(cHeadText, "ATK") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[3].fAtkRate);
                        }
                        else if (strcmp(cHeadText, "DEF") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[3].fDefRate);
                        }
                        else if (strcmp(cHeadText, "SPD") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[3].fSpdRate);
                        }
                        else if (strcmp(cHeadText, "WEI") == 0)
                        {
                            sscanf(cReadText, "%s %s %f", &cDie, &cDie, &m_aPartsRate[3].fWeiRate);
                        }
                    }
                }
            }
        }
        // �t�@�C�������
        fclose(pFile);
    }
    // �J���Ȃ�������
    else
    {
        printf("�J����܂���ł���\n");

        return E_FAIL;
    }
    //======================================================================================

    return S_OK;
}

//=============================================================================
// �I������
// Author : �㓡�T�V��
//=============================================================================
void CModelData::Uninit(void)
{
    for (int nCount = 0; nCount < MAX_MODEL_DATA; nCount++)
    {
        // ���b�V���̔j��
        if (m_aModelData[nCount].pMesh != NULL)
        {
            m_aModelData[nCount].pMesh->Release();
            m_aModelData[nCount].pMesh = NULL;
        }

        // �}�e���A���̔j��
        if (m_aModelData[nCount].pBuffMat != NULL)
        {
            m_aModelData[nCount].pBuffMat->Release();
            m_aModelData[nCount].pBuffMat = NULL;
        }
    }
}

//=============================================================================
// ���f���f�[�^���̎󂯎��̏���
// Author : �㓡�T�V��
//=============================================================================
CModelData::ModelData* CModelData::GetModelData(const int nNum)
{
    if (nNum < MAX_MODEL_DATA && nNum >= 0)
    {
        if (&m_aModelData[nNum] != NULL)
        {
            return &m_aModelData[nNum];
        }
    }

    return NULL;
}

//=============================================================================
// �p�[�c���X�g���̎󂯎��̏���
// Author : �㓡�T�V��
//=============================================================================
CModelData::PartsParam* CModelData::GetPartsList(const int nNum)
{
    if (nNum < MAX_PARTS_LIST && nNum >= 0)
    {
        if (&m_aPartsList[nNum] != NULL)
        {
            return &m_aPartsList[nNum];
        }
    }

    return NULL;
}

//=============================================================================
// �p�[�c���[�g���̎󂯎��̏���
// Author : �㓡�T�V��
//=============================================================================
CModelData::PartsRate* CModelData::GetPartsRate(const int nNum)
{
    if (nNum < MAX_PARTS && nNum >= 0)
    {
        if (&m_aPartsRate[nNum] != NULL)
        {
            return &m_aPartsRate[nNum];
        }
    }

    return NULL;
}